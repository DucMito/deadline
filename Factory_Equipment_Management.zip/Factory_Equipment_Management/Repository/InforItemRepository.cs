﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Factory_Equipment_Management.Repository
{
    public class InforItemRepository
    {
        private readonly YourDbContext _context;

        public InforItemRepository(YourDbContext context)
        {
            _context = context;
        }

        public async Task<(List<InforItemViewModel> Items, int TotalCount)> GetPagedAsync(
            int page, int pageSize, string name = null,
            float? maintanceCycle = null,
            float? duration = null,
            double? alertMaintance = null,
            double? alertRenew = null, int? idRealCategory = null,
             string nameRealCategory = null)
        {
            var query = from c in _context.Categories
                        join rc in _context.RealCategories on c.idrealCategory equals rc.idRealCategory into rcJoin
                        from rc in rcJoin.DefaultIfEmpty()
                        select new InforItemViewModel
                        {
                            IdCategory = c.idCategory,
                            Name = c.name,
                            ImageBase64 = _context.Items
                                .Where(i => i.idCategory == c.idCategory && i.image != null)
                                .Select(i => "data:image/png;base64," + Convert.ToBase64String(StringToByteArray(i.image)))
                                .FirstOrDefault(),
                            MaintanceCycle = _context.Items
                                .Where(i => i.idCategory == c.idCategory)
                                .Select(i => i.maintanceCycle)
                                .FirstOrDefault(),
                            Duration = _context.Items
                                .Where(i => i.idCategory == c.idCategory)
                                .Select(i => i.duration)
                                .FirstOrDefault(),
                            AlertMaintance = c.alertMaintance,
                            AlertRenew = c.alertRenew,
                            idRealCategory = rc != null ? rc.idRealCategory : 0,
                            nameRealCategory = rc != null ? rc.name : ""
                        };

            if (!string.IsNullOrWhiteSpace(name))
                query = query.Where(x => x.Name.Contains(name));
            if (maintanceCycle.HasValue)
                query = query.Where(x => x.MaintanceCycle == maintanceCycle);
            if (duration.HasValue)
                query = query.Where(x => x.Duration == duration);
            if (alertMaintance.HasValue)
                query = query.Where(x => x.AlertMaintance == alertMaintance);
            if (alertRenew.HasValue)
                query = query.Where(x => x.AlertRenew == alertRenew);
            // Thêm điều kiện của 2 trường idRealCategory và nameRealCategory
            if (idRealCategory.HasValue)
                query = query.Where(x => x.idRealCategory == idRealCategory.Value);
            if (!string.IsNullOrWhiteSpace(nameRealCategory))
                query = query.Where(x => x.nameRealCategory.Contains(nameRealCategory));

            int totalCount = await query.CountAsync();
            var items = await query.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
            return (items, totalCount);
        }

        // Hàm chuyển đổi chuỗi hex sang mảng byte (nếu cần)
        private static byte[] StringToByteArray(string hex)
        {
            if (string.IsNullOrEmpty(hex)) return new byte[0];
            hex = hex.Replace("-", "").Replace(" ", "");
            if (hex.Length % 2 != 0)
                hex = "0" + hex;
            int numberChars = hex.Length;
            byte[] bytes = new byte[numberChars / 2];
            for (int i = 0; i < numberChars; i += 2)
            {
                bytes[i / 2] = System.Convert.ToByte(hex.Substring(i, 2), 16);
            }
            return bytes;
        }


        public async Task<bool> UpdateItemAsync(InforItemViewModel model)
        {
            var category = await _context.Categories.FirstOrDefaultAsync(c => c.idCategory == model.IdCategory);
            if (category == null) return false;

            // Nếu chọn Other, tạo realCategory mới
            if (!string.IsNullOrWhiteSpace(model.NewRealCategory))
            {
                var newRealCat = new RealCategory { name = model.NewRealCategory };
                _context.RealCategories.Add(newRealCat);
                await _context.SaveChangesAsync();
                category.idrealCategory = newRealCat.idRealCategory;
            }
            else if (model.idRealCategory > 0)
            {
                category.idrealCategory = model.idRealCategory;
            }

            // Cập nhật các trường khác
            category.name = model.Name;
            category.alertMaintance = model.AlertMaintance;
            category.alertRenew = model.AlertRenew;

            var items = await _context.Items.Where(i => i.idCategory == model.IdCategory).ToListAsync();
            foreach (var item in items)
            {
                item.maintanceCycle = model.MaintanceCycle ?? 0f;
                item.duration = model.Duration ?? 0f;
            }

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<string>> GetDeviceNamesAsync(string term)
        {
            return await _context.Categories
                .Where(c => c.name.Contains(term))
                .Select(c => c.name)
                .ToListAsync();
        }

        public async Task<List<object>> GetAllRealCategoriesAsync()
        {
            return await _context.RealCategories
                .Select(rc => new { rc.idRealCategory, rc.name })
                .ToListAsync<object>();
        }

        // Lấy danh sách các giá trị duy nhất cho dropdown
        public async Task<List<float>> GetUniqueMaintanceCyclesAsync()
        {
            return await _context.Items
                .Where(i => i.maintanceCycle > 0)
                .Select(i => i.maintanceCycle)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<float>> GetUniqueDurationsAsync()
        {
            return await _context.Items
                .Where(i => i.duration > 0)
                .Select(i => i.duration)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<double>> GetUniqueAlertMaintancesAsync()
        {
            return await _context.Categories
                .Where(c => c.alertMaintance.HasValue && c.alertMaintance > 0)
                .Select(c => c.alertMaintance.Value)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }

        public async Task<List<double>> GetUniqueAlertRenewsAsync()
        {
            return await _context.Categories
                .Where(c => c.alertRenew.HasValue && c.alertRenew > 0)
                .Select(c => c.alertRenew.Value)
                .Distinct()
                .OrderBy(x => x)
                .ToListAsync();
        }


        public async Task<bool> AddItemAsync(InforItemViewModel model)
        {
            try
            {
                int idRealCategory = model.idRealCategory;

                // Nếu chọn Other, tạo realCategory mới
                if (!string.IsNullOrWhiteSpace(model.NewRealCategory))
                {
                    var newRealCat = new RealCategory { name = model.NewRealCategory };
                    _context.RealCategories.Add(newRealCat);
                    await _context.SaveChangesAsync();
                    idRealCategory = newRealCat.idRealCategory;
                }

                // Nếu không có idRealCategory hợp lệ, trả về false
                if (idRealCategory == 0)
                    throw new Exception("Chưa chọn hoặc nhập Category thực!");

                // Tạo Category mới
                var category = new Category
                {
                    name = model.Name,
                    idrealCategory = idRealCategory,
                    alertMaintance = model.AlertMaintance,
                    alertRenew = model.AlertRenew
                };
                _context.Categories.Add(category);
                await _context.SaveChangesAsync();

                // Tạo Item mới
                var item = new Item
                {
                    idCategory = category.idCategory,
                    maintanceCycle = model.MaintanceCycle ?? 0f,
                    duration = model.Duration ?? 0f,
                    contractor = "" // hoặc "N/A" hoặc giá trị mặc định phù hợp với hệ thống của bạn
                                    // các trường khác nếu cần
                };
                _context.Items.Add(item);
                await _context.SaveChangesAsync();

                return true;
            }
            catch (Exception ex)
            {
                // Ghi log hoặc throw lại để controller bắt được
                throw new Exception("AddItemAsync error: " + ex.Message, ex);
            }
        }

    }
}