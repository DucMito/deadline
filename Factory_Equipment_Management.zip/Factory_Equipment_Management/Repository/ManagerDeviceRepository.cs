﻿    using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.Drawing.Printing;
using System.Security.Claims;

namespace Factory_Equipment_Management.Repository
{
    public class ManagerDeviceRepository
    {
        private readonly YourDbContext _context;

        public ManagerDeviceRepository(YourDbContext context)
        {
            _context = context;
        }

        public async Task<(List<DeviceDisplayModel> Items, int TotalItems)> GetDevicesAsync(
                int pageNumber, int pageSize, string status = null,
                string deviceName = null, string location = null,
                string comment = null, string serialNumber = null, string supplier = null, string contractor = null, int? idRealCategory = null, string nameRealCategory = null)
            {
            var query = from item in _context.Items
                        join category in _context.Categories on item.idCategory equals category.idCategory into catJoin
                        from category in catJoin.DefaultIfEmpty()
                        join area in _context.Areas on item.idArea equals area.idArea into areaJoin
                        from area in areaJoin.DefaultIfEmpty()
                        join warehouse in _context.Warehouses on area.idWarehouse equals warehouse.idWarehouse into wareJoin
                        from warehouse in wareJoin.DefaultIfEmpty()
                        join realCategory in _context.RealCategories on category.idrealCategory equals realCategory.idRealCategory into realCatJoin
                        from realCategory in realCatJoin.DefaultIfEmpty()
                        select new DeviceDisplayModel
                        {
                            idItem = item.idItem,
                            ItemName = category != null ? category.name : "",
                            idCategory = item.idCategory ?? 0,
                            Name = category != null ? category.name : "",
                            CategoryName = category != null ? category.name : "",
                            LocationName = area != null ? area.name : "",
                            WarehouseName = warehouse != null ? warehouse.name : "",
                            image = item.image,
                            status = item.status,
                            activedDate = item.activedDate,
                            maintanceDate = item.maintanceDate,
                            dangKiem = item.dangKiem,
                            renewDate = item.renewDate,
                            type = item.type,
                            Quantity = null,
                            IsSelected = false,
                            Note = null,
                            supplier = item.supplier != null ? item.supplier : "",
                            contractor = item.contractor != null ? item.contractor : "",
                            comment = item.comment != null ? item.comment : "",
                            serialNumber = item.serialNumber != null ? item.serialNumber : "",
                            idRealCategory = realCategory != null ? realCategory.idRealCategory : 0,
                            nameRealCategory = realCategory != null ? realCategory.name : ""
                        };
            if (!string.IsNullOrEmpty(status))
                query = query.Where(d => d.status == status);
            if (!string.IsNullOrEmpty(deviceName))
                query = query.Where(d => d.ItemName.Contains(deviceName));
            if (!string.IsNullOrEmpty(location))
                query = query.Where(d => d.LocationName.Contains(location));
            //if (activedDate.HasValue)
            //    query = query.Where(d => d.activedDate.HasValue && d.activedDate.Value.Date == activedDate.Value.Date);
            //if (maintanceDate.HasValue)
            //    query = query.Where(d => d.maintanceDate.HasValue && d.maintanceDate.Value.Date == maintanceDate.Value.Date);
            //if (renewDate.HasValue)
            //    query = query.Where(d => d.renewDate.HasValue && d.renewDate.Value.Date == renewDate.Value.Date);

            if(!string.IsNullOrEmpty(comment))
                query = query.Where(d => d.comment != null && d.comment.Contains(comment));
            if (!string.IsNullOrEmpty(serialNumber))
                query = query.Where(d => d.serialNumber != null && d.serialNumber.Contains(serialNumber));
            if (!string.IsNullOrEmpty(supplier))
                query = query.Where(d => d.supplier != null && d.supplier.Contains(supplier));
            if (!string.IsNullOrEmpty(contractor))
                query = query.Where(d => d.contractor != null && d.contractor.Contains(contractor));
            // Thêm 2 câu lệnh cho idRealCategory và nameRealCategory
            if (idRealCategory.HasValue)
                query = query.Where(d => d.idRealCategory == idRealCategory.Value);
            if (!string.IsNullOrEmpty(nameRealCategory))
                query = query.Where(d => d.nameRealCategory != null && d.nameRealCategory.Contains(nameRealCategory));

            int totalItems = await query.CountAsync();
        var items = await query.Skip((pageNumber - 1) * pageSize).Take(pageSize).ToListAsync();
    return (items, totalItems);
        }

        public async Task<bool> ChangeStatusAsync(int id, ClaimsPrincipal user)
        {
            var role = user.Claims.FirstOrDefault(c => c.Type == System.Security.Claims.ClaimTypes.Role)?.Value;
            if (role != "Admin" && role != "Manager") return false;

            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == id);
            if (item == null) return false;

            item.status = "Dự phòng";
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Item> GetByIdAsync(int? idItem)
        {
            return await _context.Items.FirstOrDefaultAsync(d => d.idItem == idItem);
        }

        public async Task UpdateAsync(Item device)
        {
            _context.Items.Update(device);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> UpdateDeviceAsync(DeviceDisplayModel model)
        {
            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == model.idItem);
            if (item == null) return false;

            if (model.idArea != null && !await _context.Areas.AnyAsync(a => a.idArea == model.idArea))
                return false;

            if (!await _context.Categories.AnyAsync(c => c.idCategory == model.idCategory))
                return false;

            item.idCategory = model.idCategory;
            item.idArea = model.idArea ?? item.idArea;
            item.status = model.status;
            item.activedDate = model.activedDate;
            item.maintanceDate = model.maintanceDate;
            item.renewDate = model.renewDate;

            // Bổ sung cập nhật các trường mới
            item.comment = model.comment;
            item.serialNumber = model.serialNumber;
            item.contractor = model.contractor;
            item.supplier = model.supplier;

            await _context.SaveChangesAsync();
            return true;
        }

        // Delete items
        public async Task<bool> DeleteDeviceAsync(int id)
        {
            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == id);
            if (item == null) return false;
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}