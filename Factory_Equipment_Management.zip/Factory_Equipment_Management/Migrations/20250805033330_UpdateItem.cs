﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Factory_Equipment_Management.Migrations
{
    /// <inheritdoc />
    public partial class UpdateItem : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Thêm cột 'comment'
            migrationBuilder.AddColumn<string>(
                name: "comment",
                table: "Item",
                type: "longtext",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Xóa cột 'comment'
            migrationBuilder.DropColumn(
                name: "comment",
                table: "Item");
        }
    }
}