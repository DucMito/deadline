﻿document.addEventListener('DOMContentLoaded', function () {
    // ================== POPUP CẬP NHẬT ==================
    // Hàm fetch tất cả realCategory và render vào select
    async function loadRealCategories(selectedId, selectedName) {
        const res = await fetch('/InforItem/GetAllRealCategories');
        const categories = await res.json();
        const select = document.getElementById('updateRealCategorySelect');
        select.innerHTML = '';

        categories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat.idRealCategory;
            opt.textContent = cat.name;
            if (cat.idRealCategory == selectedId) opt.selected = true;
            select.appendChild(opt);
        });

        // Thêm option Other
        const otherOpt = document.createElement('option');
        otherOpt.value = 'other';
        otherOpt.textContent = 'Other...';
        select.appendChild(otherOpt);

        // Nếu đang chọn Other
        if (selectedId === 'other') {
            select.value = 'other';
            document.getElementById('updateRealCategoryOther').style.display = '';
            document.getElementById('updateRealCategoryOther').value = selectedName || '';
        } else {
            document.getElementById('updateRealCategoryOther').style.display = 'none';
            document.getElementById('updateRealCategoryOther').value = '';
        }

        // Gán lại sự kiện change mỗi lần load
        select.onchange = function () {
            const otherInput = document.getElementById('updateRealCategoryOther');
            if (this.value === 'other') {
                otherInput.style.display = 'block';
            } else {
                otherInput.style.display = 'none';
                otherInput.value = '';
            }
        };
    }

    // Hiển thị popup khi bấm nút cập nhật
    document.querySelectorAll('.update-button').forEach(function (btn) {
        btn.addEventListener('click', function () {
            document.getElementById('updateIdCategory').value = btn.getAttribute('data-idcategory');
            document.getElementById('updateName').value = btn.getAttribute('data-name');
            document.getElementById('updateMaintanceCycle').value = btn.getAttribute('data-maintancecycle');
            document.getElementById('updateDuration').value = btn.getAttribute('data-duration');
            document.getElementById('updateAlertMaintance').value = btn.getAttribute('data-alertmaintance');
            document.getElementById('updateAlertRenew').value = btn.getAttribute('data-alertrenew');
            // Load realCategory dropdown
            loadRealCategories(btn.getAttribute('data-idrealcategory'), btn.getAttribute('data-namerealcategory'));
            document.getElementById('updatePopup').style.display = 'flex';
        });
    });

    // Đóng popup khi bấm nút đóng
    document.getElementById('closePopup').addEventListener('click', function () {
        document.getElementById('updatePopup').style.display = 'none';
    });

    // Xử lý submit form cập nhật
    document.getElementById('updateForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);

        const realCategorySelect = document.getElementById('updateRealCategorySelect');
        if (realCategorySelect.value === 'other') {
            formData.set('idRealCategory', '');
            formData.set('NewRealCategory', document.getElementById('updateRealCategoryOther').value);
        } else {
            formData.set('idRealCategory', realCategorySelect.value);
            formData.set('NewRealCategory', '');
        }

        fetch('/InforItem/Update', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                alert(data.message || 'Cập nhật thành công!');
                location.reload();
            })
            .catch(() => alert('Không thể kết nối server!'));
    });

    // ================== POPUP THÊM MỚI ==================
    document.getElementById('addItemBtn').addEventListener('click', function () {
        loadAddRealCategories();
        document.getElementById('addPopup').style.display = 'flex';
    });

    document.getElementById('closeAddPopup').addEventListener('click', function () {
        document.getElementById('addPopup').style.display = 'none';
    });

    // Không tự động đóng popup khi click ra ngoài
    // Nếu muốn đóng khi click overlay, chỉ nên dùng đoạn sau:
    // document.getElementById('addPopup').addEventListener('mousedown', function (e) {
    //     if (e.target === this) {
    //         this.style.display = 'none';
    //     }
    // });

    // Load realCategory cho form thêm mới
    async function loadAddRealCategories() {
        const res = await fetch('/InforItem/GetAllRealCategories');
        const categories = await res.json();
        const select = document.getElementById('addRealCategorySelect');
        select.innerHTML = '';

        categories.forEach(cat => {
            const opt = document.createElement('option');
            opt.value = cat.idRealCategory;
            opt.textContent = cat.name;
            select.appendChild(opt);
        });

        // Thêm option Other
        const otherOpt = document.createElement('option');
        otherOpt.value = 'other';
        otherOpt.textContent = 'Other...';
        select.appendChild(otherOpt);

        document.getElementById('addRealCategoryOther').style.display = 'none';
        document.getElementById('addRealCategoryOther').value = '';

        select.onchange = function () {
            const otherInput = document.getElementById('addRealCategoryOther');
            if (this.value === 'other') {
                otherInput.style.display = 'block';
            } else {
                otherInput.style.display = 'none';
                otherInput.value = '';
            }
        };
    }

    // Xử lý submit form thêm mới
    document.getElementById('addForm').addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(this);

        const realCategorySelect = document.getElementById('addRealCategorySelect');
        if (realCategorySelect.value === 'other') {
            formData.set('idRealCategory', '');
            formData.set('NewRealCategory', document.getElementById('addRealCategoryOther').value);
        } else {
            formData.set('idRealCategory', realCategorySelect.value);
            formData.set('NewRealCategory', '');
        }

        fetch('/InforItem/Add', {
            method: 'POST',
            body: formData
        })
            .then(res => res.json())
            .then(data => {
                alert(data.message || 'Thêm thành công!');
                location.reload();
            })
            .catch(() => alert('Không thể kết nối server!'));
    });

    // ================== AUTOCOMPLETE TÊN THIẾT BỊ ==================
    const nameInput = document.getElementById('deviceNameSearch');
    const suggestionBox = document.getElementById('deviceNameSuggestions');
    let lastQuery = null;

    // Hàm tính toán vị trí dropdown - Đơn giản hóa
    function positionDropdown() {
        if (nameInput && suggestionBox) {
            // Không cần set width nữa, CSS đã handle
        }
    }

    if (nameInput && suggestionBox) {
        // Khi focus vào input, nếu chưa nhập gì thì show toàn bộ danh sách
        nameInput.addEventListener('focus', function () {
            if (!this.value.trim()) {
                fetch('/InforItem/GetDeviceNames')
                    .then(res => res.json())
                    .then(data => {
                        if (Array.isArray(data) && data.length > 0) {
                            suggestionBox.innerHTML = data.map(name => `<div>${name}</div>`).join('');
                            positionDropdown();
                            suggestionBox.style.display = 'block';
                            suggestionBox.classList.add('show');
                        } else {
                            suggestionBox.innerHTML = '';
                            suggestionBox.style.display = 'none';
                            suggestionBox.classList.remove('show');
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching device names:', error);
                    });
            }
        });

        // Khi gõ, luôn search theo từ khóa (kể cả rỗng)
        nameInput.addEventListener('input', function () {
            const query = this.value.trim();
            if (query === lastQuery) return;
            lastQuery = query;
            fetch(`/InforItem/GetDeviceNames?term=${encodeURIComponent(query)}`)
                .then(res => res.json())
                .then(data => {
                    if (Array.isArray(data) && data.length > 0) {
                        suggestionBox.innerHTML = data.map(name => `<div>${name}</div>`).join('');
                        positionDropdown();
                        suggestionBox.style.display = 'block';
                        suggestionBox.classList.add('show');
                    } else {
                        suggestionBox.innerHTML = '';
                        suggestionBox.style.display = 'none';
                        suggestionBox.classList.remove('show');
                    }
                })
                .catch(error => {
                    console.error('Error fetching filtered device names:', error);
                });
        });

        // Khi chọn 1 tên trong list
        suggestionBox.addEventListener('click', function (e) {
            if (e.target && e.target.nodeName === 'DIV') {
                nameInput.value = e.target.textContent;
                suggestionBox.innerHTML = '';
                suggestionBox.style.display = 'none';
                suggestionBox.classList.remove('show');
            }
        });

        // Ẩn list khi click ra ngoài autocomplete
        document.addEventListener('mousedown', function (e) {
            if (
                e.target === nameInput ||
                suggestionBox.contains(e.target)
            ) {
                return;
            }
            suggestionBox.innerHTML = '';
            suggestionBox.style.display = 'none';
            suggestionBox.classList.remove('show');
        });

        // Reposition dropdown khi scroll hoặc resize
        window.addEventListener('scroll', positionDropdown);
        window.addEventListener('resize', positionDropdown);
    }

    document.getElementById('addPopup').addEventListener('mousedown', function (e) {
        // Chỉ đóng khi click đúng vào overlay, không phải nội dung popup
        if (e.target === this) {
            this.style.display = 'none';
        }
    });
});