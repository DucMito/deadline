﻿document.addEventListener('DOMContentLoaded', () => {
    // --- Render bảng cho staff, pic, manager ---
    function renderAccountTable(type, data) {
        const thead = `
            <tr>
                <th>id</th>
                <th>Tên</th>
                <th>username</th>
                <th>password</th>
                <th>email</th>
                <th>Thao tác</th>
            </tr>`;
        const rows = data.map(acc => {
            let id = '';
            if (type === 'staff') id = acc.idStaff;
            else if (type === 'pic') id = acc.idPIC;
            else if (type === 'manager') id = acc.idManager;
            return `<tr data-id="${id}">
                <td>${id}</td>
                <td><input type="text" value="${acc.name || ''}" class="edit-name" /></td>
                <td><input type="text" value="${acc.username || ''}" class="edit-username" /></td>
                <td><input type="text" value = "" placeholder="Để trống nếu không đổi" class="edit-password" /></td>
                <td><input type="text" value="${acc.email || ''}" class="edit-email" /></td>
                <td>
                    <button class="btn-update">Update</button>
                    <button class="btn-delete">Delete</button>
                </td>
            </tr>`;
        }).join('');
        document.getElementById('account-table-container').innerHTML =
            `<table class="account-table"><thead>${thead}</thead><tbody>${rows}</tbody></table>`;
    }

    // --- Render bảng warehouse/area ---
    function renderWarehouseTable(data) {
        fetch('/Admin/GetPicAccounts').then(res => res.json()).then(pics => {
            let html = `
            <table class="account-table">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>Tên</th>
                        <th>Người quản lí</th>
                        <th>Khu vực</th>
                        <th >Thao tác</th>
                    </tr>
                </thead>
                <tbody>
        `;
            data.forEach(w => {
                html += `
            <tr data-id="${w.idWarehouse}">
                <td>${w.idWarehouse}</td>
                <td><input type="text" value="${w.name}" class="edit-warehouse-name" /></td>
                <td>
                    <select class="edit-warehouse-pic">
                        ${pics.map(pic => `<option value="${pic.idPIC}" ${w.idPIC === pic.idPIC ? 'selected' : ''}>${pic.name}</option>`).join('')}
                    </select>
                </td>
                <td>
                    <div class="area-list">
                        ${w.areas.map(a => `
                            <div class="area-item" data-area-id="${a.idArea}">
                                <input type="text" value="${a.name}" class="edit-area-name" />
                                <button class="btn-update-area" data-area-id="${a.idArea}">&#10003;</button>
                                <button class="btn-delete-area" data-area-id="${a.idArea}">&times;</button>
                            </div>
                        `).join('')}
                    </div>
                </td>
                <td>
                    <button class="btn-update-warehouse" data-id="${w.idWarehouse}">Cập nhật</button>
                    <button class="btn-delete-warehouse" data-id="${w.idWarehouse}">Xóa</button>
                </td>
            </tr>
            `;
            });
            html += `</tbody></table>`;
            document.getElementById('account-table-container').innerHTML = html;
        });
    }

    // Hiển thị form thêm kho mới
    async function renderAddWarehouseForm() {
        const res = await fetch('/Admin/GetPicAccounts');
        const pics = await res.json();
        document.getElementById('add-form-container').innerHTML = `
        <form id="add-warehouse-form" style="margin-bottom:16px;display:flex;gap:8px;flex-wrap:wrap;">
            <input type="text" name="name" placeholder="Tên kho" required />
            <select name="idPIC" required>
                <option value="">Chọn PIC quản lý</option>
                ${pics.map(pic => `<option value="${pic.idPIC}">${pic.name}</option>`).join('')}
            </select>
            <button type="submit" class="btn-create">Thêm kho</button>
        </form>
        <div id="add-warehouse-error" style="color:red;margin-top:4px;"></div>
    `;
        document.getElementById('add-warehouse-form').onsubmit = async function (e) {
            e.preventDefault();
            const formData = new FormData(this);
            const body = {
                name: formData.get('name'),
                idPIC: Number(formData.get('idPIC'))
            };
            const res = await fetch('/Admin/AddWarehouse', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            if (res.ok) {
                loadWarehouses();
                this.reset();
                document.getElementById('add-warehouse-error').innerText = '';
            } else {
                document.getElementById('add-warehouse-error').innerText = await res.text() || 'Lỗi thêm kho';
            }
        };
    }

    // --- Load dữ liệu ---
    async function loadAccounts(type) {
        let url = '';
        switch (type) {
            case 'staff': url = '/Admin/GetStaffAccounts'; break;
            case 'pic': url = '/Admin/GetPicAccounts'; break;
            case 'manager': url = '/Admin/GetManagerAccounts'; break;
            default: url = ''; break;
        }
        if (!url) {
            document.getElementById('account-table-container').innerHTML = '';
            document.getElementById('add-form-container').innerText = '';
            return;
        }
        const res = await fetch(url);
        const data = await res.json();
        renderAccountTable(type, data);
        renderAddForm(type);
    }

    async function loadWarehouses() {
        const res = await fetch('/Admin/GetWarehousesWithAreas');
        const data = await res.json();
        renderWarehouseTable(data);
        renderAddWarehouseForm();
        renderAddAreaForm(data);
    }

    // --- Render form thêm mới ---
    function renderAddForm(type) {
        let url = '';
        switch (type) {
            case 'staff': url = '/Admin/AddStaff'; break;
            case 'pic': url = '/Admin/AddPic'; break;
            case 'manager': url = '/Admin/AddManager'; break;
            default: url = ''; break;
        }
        if (!url) {
            document.getElementById('add-form-container').innerHTML = '';
            return;
        }
        document.getElementById('add-form-container').innerHTML = `
            <form id="add-form" style="margin-bottom:16px;display:flex;gap:8px;flex-wrap:wrap;">
                <input type="text" name="name" placeholder="Tên" required />
                <input type="text" name="username" placeholder="Username" required />
                <input type="text" name="password" placeholder="Password" required />
                <input type="text" name="email" placeholder="Email" required />
                <button type="submit" style="background:#27ae60;color:#fff;border-radius: 14px; border: none;">Thêm mới</button>
            </form>
            <div id="add-error" style="color:red;margin-top:4px;"></div>
        `;
        document.getElementById('add-form').onsubmit = async function (e) {
            e.preventDefault();
            const formData = new FormData(this);
            const res = await fetch(url, { method: 'POST', body: formData });
            if (res.ok) {
                loadAccounts(type);
                this.reset();
                document.getElementById('add-error').innerText = '';
            } else {
                document.getElementById('add-error').innerText = await res.text() || 'Lỗi thêm mới';
            }
        };
    }

    // --- Sự kiện click tab ---
    document.querySelectorAll('.account-type-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.account-type-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const type = btn.getAttribute('data-type');

            // Thêm/xóa class warehouse-active cho container
            const container = document.querySelector('.account-container');
            if (type === 'warehouse') {
                container.classList.add('warehouse-active');
                loadWarehouses();
            } else {
                container.classList.remove('warehouse-active');
                loadAccounts(type);
            }
        });
    });

    // --- Sự kiện update/delete cho staff, pic, manager, warehouse, area ---
    document.getElementById('account-table-container').addEventListener('click', async function (e) {
        const tr = e.target.closest('tr');
        if (!tr) return;
        const type = document.querySelector('.account-type-btn.active').getAttribute('data-type');
        let id = tr.getAttribute('data-id');

        // Sửa account
        if (e.target.classList.contains('btn-update')) {
            let name = tr.querySelector('.edit-name').value;
            let username = tr.querySelector('.edit-username').value;
            let password = tr.querySelector('.edit-password').value;
            let email = tr.querySelector('.edit-email').value;
            let url = '';
            let body = {};
            if (type === 'staff') {
                url = '/Admin/UpdateStaff';
                body = { idStaff: Number(id), name, username, password, email };
            } else if (type === 'pic') {
                url = '/Admin/UpdatePic';
                body = { idPIC: Number(id), name, username, password, email };
            } else if (type === 'manager') {
                url = '/Admin/UpdateManager';
                body = { idManager: Number(id), name, username, password, email };
            }
            const res = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            if (res.ok) {
                loadAccounts(type);
                alert('Cập nhật thành công!');
            } else {
                alert(await res.text() || 'Lỗi cập nhật');
            }
        }

        // Xóa account
        if (e.target.classList.contains('btn-delete')) {
            if (!confirm('Bạn có chắc muốn xóa?')) return;
            let url = '';
            switch (type) {
                case 'staff': url = `/Admin/DeleteStaff?id=${id}`; break;
                case 'pic': url = `/Admin/DeletePic?id=${id}`; break;
                case 'manager': url = `/Admin/DeleteManager?id=${id}`; break;
            }
            const res = await fetch(url, { method: 'POST' });
            if (res.ok) {
                loadAccounts(type);
            } else {
                alert(await res.text() || 'Lỗi xóa');
            }
        }

        // Cập nhật warehouse
        if (e.target.classList.contains('btn-update-warehouse')) {
            const idWarehouse = e.target.getAttribute('data-id');
            const name = tr.querySelector('.edit-warehouse-name').value;
            const idPIC = tr.querySelector('.edit-warehouse-pic').value;
            const res = await fetch('/Admin/UpdateWarehouse', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ idWarehouse: Number(idWarehouse), name, idPIC: Number(idPIC) })
            });
            if (res.ok) {
                loadWarehouses();
                alert('Cập nhật thành công!');
            } else {
                alert(await res.text() || 'Lỗi cập nhật');
            }
        }

        // Xóa warehouse
        if (e.target.classList.contains('btn-delete-warehouse')) {
            if (!confirm('Bạn có chắc muốn xóa kho này?')) return;
            const idWarehouse = e.target.getAttribute('data-id');
            const res = await fetch(`/Admin/DeleteWarehouse?id=${idWarehouse}`, { method: 'POST' });
            if (res.ok) {
                loadWarehouses();
            } else {
                alert(await res.text() || 'Lỗi xóa kho');
            }
        }

        // Cập nhật area
        if (e.target.classList.contains('btn-update-area')) {
            const areaId = e.target.getAttribute('data-area-id');
            const areaItem = e.target.closest('.area-item');
            const name = areaItem.querySelector('.edit-area-name').value;
            const idWarehouse = tr.getAttribute('data-id');
            if (!name.trim()) {
                alert('Tên khu vực không được để trống!');
                return;
            }
            const res = await fetch('/Admin/UpdateArea', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ idArea: Number(areaId), name: name.trim(), idWarehouse: Number(idWarehouse) })
            });
            if (res.ok) {
                loadWarehouses();
                alert('Cập nhật khu vực thành công!');
            } else {
                alert(await res.text() || 'Lỗi cập nhật khu vực');
            }
        }

        // Xóa area
        if (e.target.classList.contains('btn-delete-area')) {
            if (!confirm('Bạn có chắc muốn xóa khu vực này?')) return;
            const areaId = e.target.getAttribute('data-area-id');
            const res = await fetch(`/Admin/DeleteArea?id=${areaId}`, { method: 'POST' });
            if (res.ok) {
                loadWarehouses();
            } else {
                alert(await res.text() || 'Lỗi xóa khu vực');
            }
        }
    });

    // --- Form thêm area ---
    function renderAddAreaForm(warehouses) {
        document.getElementById('add-area-form-container').innerHTML = `
        <form id="add-area-form" style="margin-bottom:16px;display:flex;gap:8px;flex-wrap:wrap;">
            <select name="idWarehouse" required>
                <option value="">Chọn kho</option>
                ${warehouses.map(w => `<option value="${w.idWarehouse}">${w.name}</option>`).join('')}
            </select>
            <input type="text" name="name" placeholder="Tên khu vực" required />
            <button type="submit" class="btn-create">Thêm khu vực</button>
        </form>
        <div id="add-area-error" style="color:red;margin-top:4px;"></div>
    `;
        document.getElementById('add-area-form').onsubmit = async function (e) {
            e.preventDefault();
            const formData = new FormData(this);
            const body = {
                idWarehouse: Number(formData.get('idWarehouse')),
                name: formData.get('name')
            };
            const res = await fetch('/Admin/AddArea', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            if (res.ok) {
                loadWarehouses();
                this.reset();
                document.getElementById('add-area-error').innerText = '';
            } else {
                document.getElementById('add-area-error').innerText = await res.text() || 'Lỗi thêm khu vực';
            }
        };
    }

    // --- Tải mặc định là staff ---
    // Đảm bảo không có class warehouse-active khi load lần đầu
    document.querySelector('.account-container').classList.remove('warehouse-active');
    loadAccounts('staff');
});