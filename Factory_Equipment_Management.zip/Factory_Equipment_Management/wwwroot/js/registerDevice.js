﻿document.addEventListener("DOMContentLoaded", function () {
    // Xử lý chi tiết thiết bị
    document.querySelectorAll('.btn-detail').forEach(btn => {
        btn.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            fetch(`/RegisterDevice/GetDeviceDetail?id=${id}`)
                .then(res => res.json())
                .then(data => {
                    document.getElementById('detailName').textContent = data.name || '';
                    document.getElementById('detailImage').src = data.imageBase64 || '';
                    document.getElementById('detailNum').textContent = data.num ?? '';
                    document.getElementById('detailPO').textContent = data.po || '';
                    document.getElementById('detailMaintainceCycle').textContent = data.maintainceCycle ?? '';
                    document.getElementById('detailRenewCycle').textContent = data.renewCycle ?? '';
                    document.getElementById('deviceDetailModal').style.display = 'block';
                });
        });
    });

    // Đóng popup chi tiết
    const closeModalBtn = document.getElementById('closeModalBtn');
    if (closeModalBtn) {
        closeModalBtn.onclick = function () {
            document.getElementById('deviceDetailModal').style.display = 'none';
        };
    }

    // Popup gửi yêu cầu sản phẩm mới
    const addDeviceModal = document.getElementById('addDeviceModal');
    const btnShow = document.getElementById('btnShowAddDeviceModal');
    const btnClose = document.getElementById('closeAddDeviceModal');
    if (btnShow) btnShow.onclick = () => {
        addDeviceModal.style.display = 'block';
        addDeviceModal.style.background = 'rgba(0,0,0,0.5)';
    };
    if (btnClose) btnClose.onclick = () => addDeviceModal.style.display = 'none';

    // Đóng modal khi click ra ngoài
    window.onclick = function (event) {
        if (event.target === addDeviceModal) {
            addDeviceModal.style.display = 'none';
        }
        if (event.target === document.getElementById('deviceDetailModal')) {
            document.getElementById('deviceDetailModal').style.display = 'none';
        }
    };

    // Xử lý submit form
    const addDeviceForm = document.getElementById('addDeviceForm');
    if (addDeviceForm) {
        addDeviceForm.addEventListener('submit', async function (e) {
            e.preventDefault();

            const formData = new FormData(addDeviceForm);

            try {
                const response = await fetch('/RegisterDevice/Create', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                if (result.success) {
                    alert('Gửi yêu cầu thành công!');
                    window.location.reload();
                } else {
                    if (result.errors && Array.isArray(result.errors)) {
                        alert(result.errors.join('\n'));
                    } else {
                        alert(result.message || 'Có lỗi xảy ra khi gửi yêu cầu!');
                    }
                }
            } catch (err) {
                alert('Không thể gửi yêu cầu. Vui lòng thử lại!');
                console.log(err);
            }
        });
    }
});