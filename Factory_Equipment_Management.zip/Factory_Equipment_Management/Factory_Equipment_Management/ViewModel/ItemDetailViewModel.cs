﻿namespace Factory_Equipment_Management.ViewModel
{
    public class ItemDetailViewModel
    {
        public int? Id { get; set; }
        public string DeviceName { get; set; }
        public string Category { get; set; }
        public string Status { get; set; }

        public int? Type { get; set; }
        public string ActivedDate { get; set; }
        public string Location { get; set; }
        public string ImageUrl { get; set; }
        public string QrCodeBase64 { get; set; }
        public List<TransferHistoryModel> TransferHistory { get; set; }

        public List<MaintenanceHistoryModel> MaintenanceHistory { get; set; }
        public decimal TotalBaoDuong { get; set; }
        public decimal TotalSuaChua { get; set; }
        public decimal TotalAll { get; set; }



        // vừa thêm để giúp bạn làm thêm chức năng
        //public DateTime? activedDate { get; set; }
        public DateTime? maintanceDate { get; set; }
        public DateTime? renewDate { get; set; }
    }

    public class TransferHistoryModel
    {
        public DateTime? TransferDate { get; set; }
        public string OldLocation { get; set; }
        public string NewLocation { get; set; }
    }
}