﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Factory_Equipment_Management.Repository
{
    public class RegisterDeviceRepository
    {
        private readonly YourDbContext _context;
        public RegisterDeviceRepository(YourDbContext context)
        {
            _context = context;
        }

        public List<RegisterDeviceRequestModel> GetAllRequests()
        {
            return _context.RegisterDeviceRequests
                .Select(r => new RegisterDeviceRequestModel
                {
                    idRegisterDeviceRequest = r.idRegisterDeviceRequest,
                    date = r.date,
                    status = r.status
                })
                .OrderByDescending(r => r.date)
                .ToList();
        }

        public List<RegisterDeviceRequestModel> GetPagedRequests(int page, int pageSize, out int totalCount, string status = null)
        {
            var query = _context.RegisterDeviceRequests
                .Select(r => new RegisterDeviceRequestModel
                {
                    idRegisterDeviceRequest = r.idRegisterDeviceRequest,
                    date = r.date,
                    status = r.status
                });

            if (!string.IsNullOrEmpty(status))
            {
                query = query.Where(r => r.status == status);
            }

            query = query.OrderByDescending(r => r.date);

            totalCount = query.Count();

            return query
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToList();
        }

        public RegisterDeviceDetailViewModel GetDeviceDetail(int idRegisterDeviceRequest)
        {
            var device = _context.RegisterDevices
                 .Where(d => d.idRegisterDeviceRequest == idRegisterDeviceRequest)
                 .Select(d => new
             {
                 d.name,
                 d.image, // string hex
                 d.num,
                 d.po,
                 d.maintanceCycle,
                 d.renewCycle
             })
             .FirstOrDefault();

                    if (device == null) return null;
                    byte[] imageBytes = null;
                    if (!string.IsNullOrEmpty(device.image))
                    {
                        string hexString = device.image;
                        imageBytes = Enumerable.Range(0, hexString.Length)
                            .Where(x => x % 2 == 0)
                            .Select(x => Convert.ToByte(hexString.Substring(x, 2), 16))
                            .ToArray();
                    }

                    string imageBase64 = (imageBytes != null && imageBytes.Length > 0)
                        ? $"data:image/png;base64,{Convert.ToBase64String(imageBytes)}"
                        : "";

                    return new RegisterDeviceDetailViewModel
                    {
                        Name = device.name,
                        ImageBase64 = imageBase64,
                        Num = device.num,
                        PO = device.po,
                        MaintainceCycle = device.maintanceCycle,
                        RenewCycle = device.renewCycle
                    };
        }

        // Create new device request
        public async Task<bool> AddRegisterDeviceAsync(RegisterDeviceCreateViewModel model)
        {
            // Ghi log dữ liệu đầu vào để debug
            System.IO.File.AppendAllText("error_log.txt", $"{DateTime.Now} - INPUT: CategoryId={model.CategoryId}, IdRealCategory={model.IdRealCategory}, Name={model.Name}, Num={model.Num}, Type={model.Type}, PO={model.PO}\n");

            // Kiểm tra dữ liệu bắt buộc
            if (model.CategoryId <= 0 || model.IdRealCategory == null || string.IsNullOrWhiteSpace(model.Name) || model.Num <= 0)
            {
                System.IO.File.AppendAllText("error_log.txt", $"{DateTime.Now} - Lỗi: Dữ liệu đầu vào không hợp lệ\n");
                return false;
            }

            // Kiểm tra CategoryId và IdRealCategory có tồn tại trong DB không
            var categoryExists = _context.Categories.Any(c => c.idCategory == model.CategoryId);
            var realCategoryExists = _context.RealCategories.Any(rc => rc.idRealCategory == model.IdRealCategory);
            if (!categoryExists || !realCategoryExists)
            {
                System.IO.File.AppendAllText("error_log.txt", $"{DateTime.Now} - Lỗi: CategoryId hoặc IdRealCategory không tồn tại trong DB\n");
                return false;
            }

            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                // Xử lý ảnh
                string imageHex = null;
                if (model.Image != null && model.Image.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        await model.Image.CopyToAsync(ms);
                        byte[] imageBytes = ms.ToArray();
                        StringBuilder sb = new StringBuilder(imageBytes.Length * 2);
                        foreach (byte b in imageBytes)
                            sb.AppendFormat("{0:x2}", b);
                        imageHex = sb.ToString();
                    }
                }

                // Tạo request
                var request = new RegisterDeviceRequest
                {
                    date = DateTime.Now,
                    status = "Đang chờ"
                };
                await _context.RegisterDeviceRequests.AddAsync(request);
                await _context.SaveChangesAsync();

                // Tạo device
                var device = new RegisterDevice
                {
                    idCategory = model.CategoryId,
                    idRealCategory = (int)model.IdRealCategory,
                    name = model.Name,
                    type = model.Type == 1,
                    num = model.Num,
                    po = model.PO,
                    image = imageHex,
                    maintanceCycle = model.MaintainceCycle.HasValue ? (int)model.MaintainceCycle.Value : 0,
                    renewCycle = model.RenewCycle.HasValue ? (int)model.RenewCycle.Value : 0,
                    alertMaintance = model.AlertMaintaince.HasValue ? (int)model.AlertMaintaince.Value : 0,
                    alertRenew = model.AlertRenew.HasValue ? (int)model.AlertRenew.Value : 0,
                    dangKiem = model.DangKiemDate,
                    idRegisterDeviceRequest = request.idRegisterDeviceRequest
                };
                await _context.RegisterDevices.AddAsync(device);
                await _context.SaveChangesAsync();

                await transaction.CommitAsync();
                System.IO.File.AppendAllText("error_log.txt", $"{DateTime.Now} - Lưu thành công\n");
                return true;
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                System.IO.File.AppendAllText("error_log.txt", $"{DateTime.Now} - Lỗi: {ex}\n");
                return false;
            }
        }

        // phân trang 
        public async Task<(List<RegisterDeviceRequestModel> Requests, int TotalCount)> GetPagedRequestsAsync(int page, int pageSize, string status)
        {
            var query = _context.RegisterDeviceRequests.AsQueryable();
            if (!string.IsNullOrEmpty(status))
                query = query.Where(x => x.status == status);

            int totalCount = await query.CountAsync();

            var data = await query
                .OrderByDescending(x => x.date)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return (data.Select(x => new RegisterDeviceRequestModel
            {
                idRegisterDeviceRequest = x.idRegisterDeviceRequest,
                date = x.date,
                status = x.status
            }).ToList(), totalCount);
        }

    }
}