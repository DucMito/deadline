﻿using Factory_Equipment_Management.ViewModel;
using Factory_Equipment_Management.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;
using QRCoder;
using System.Drawing;
using System.IO;

public class ItemDetailRepository
{
    private readonly YourDbContext _context;
    public ItemDetailRepository(YourDbContext context)
    {
        _context = context;
    }

    public async Task<ItemDetailViewModel> GetItemDetailAsync(int id)
    {
        // Lấy thông tin thiết bị, category, area, warehouse
        var item = await (from i in _context.Items
                          join c in _context.Categories on i.idCategory equals c.idCategory
                          join a in _context.Areas on i.idArea equals a.idArea into areaJoin
                          from a in areaJoin.DefaultIfEmpty()
                          join w in _context.Warehouses on a.idWarehouse equals w.idWarehouse into warehouseJoin
                          from w in warehouseJoin.DefaultIfEmpty()
                          where i.idItem == id
                          select new
                          {
                              i.idItem,
                              CategoryName = c.name,
                              i.activedDate,
                              AreaName = a != null ? a.name : "",
                              WarehouseName = w != null ? w.name : "",
                              i.image,
                              i.type,
                              i.maintanceDate,
                              i.renewDate
                          }).FirstOrDefaultAsync();

        if (item == null) return null;

        // Sinh QR code từ thông tin thiết bị (ví dụ: id + category + area + warehouse)
        string qrContent = $"ID:{item.idItem};Category:{item.CategoryName};Area:{item.AreaName};Warehouse:{item.WarehouseName}";
        string qrCodeBase64 = GenerateQrCodeBase64(qrContent);

        // Lấy lịch sử bảo trì
        var maintenanceHistory = await (from mh in _context.MaintanceHistories
                                        join s in _context.Staffs on mh.idStaff equals s.idStaff into staffJoin
                                        from s in staffJoin.DefaultIfEmpty()
                                        where mh.idItem == id
                                        orderby mh.dateEnd descending
                                        select new MaintenanceHistoryModel
                                        {
                                            DateEnd = mh.dateEnd,
                                            StaffName = s != null ? s.name : "",
                                            Reason = mh.reason ?? mh.roleAccept ?? mh.type,
                                            Type = mh.type,
                                            Budget = mh.budget
                                        }).ToListAsync();

        // Tổng hợp chi phí
        decimal totalBaoDuong = maintenanceHistory.Where(x => x.Type != null && x.Type.ToLower().Contains("bảo dưỡng")).Sum(x => x.Budget ?? 0);
        decimal totalSuaChua = maintenanceHistory.Where(x => x.Type != null && x.Type.ToLower().Contains("sửa")).Sum(x => x.Budget ?? 0);
        decimal totalAll = maintenanceHistory.Sum(x => x.Budget ?? 0);

        return new ItemDetailViewModel
        {
            Id = item.idItem,
            DeviceName = item.CategoryName,
            ActivedDate = item.activedDate?.ToString("dd/MM/yyyy"),
            maintanceDate = item.maintanceDate, // Truyền sang ViewModel
            renewDate = item.renewDate,
            Location = $"{item.WarehouseName}, {item.AreaName}",
            ImageUrl = string.IsNullOrEmpty(item.image) ? "" : $"data:image/jpeg;base64,{HexToBase64(item.image)}",
            QrCodeBase64 = qrCodeBase64,
            MaintenanceHistory = maintenanceHistory,
            TotalBaoDuong = totalBaoDuong,
            TotalSuaChua = totalSuaChua,
            TotalAll = totalAll,
            Type = item.type
        };
    }
    private string HexToBase64(string hex)
    {
        if (string.IsNullOrEmpty(hex)) return "";
        try
        {
            hex = hex.Replace("-", "").Replace(" ", "");
            byte[] bytes = Enumerable.Range(0, hex.Length / 2)
                .Select(x => Convert.ToByte(hex.Substring(x * 2, 2), 16))
                .ToArray();
            return Convert.ToBase64String(bytes);
        }
        catch
        {
            return "";
        }
    }

    // Sinh QR code base64 từ chuỗi nội dung
    private string GenerateQrCodeBase64(string content)
    {
        using (var qrGenerator = new QRCodeGenerator())
        using (var qrData = qrGenerator.CreateQrCode(content, QRCodeGenerator.ECCLevel.Q))
        using (var qrCode = new QRCode(qrData))
        using (var bitmap = qrCode.GetGraphic(20))
        using (var ms = new MemoryStream())
        {
            bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            return "data:image/png;base64," + Convert.ToBase64String(ms.ToArray());
        }
    }
    


}


public class MaintenanceHistoryModel
{
    public DateTime? DateEnd { get; set; }
    public string StaffName { get; set; }
    public string Reason { get; set; }
    public string Type { get; set; }
    public decimal? Budget { get; set; }
}