﻿namespace Factory_Equipment_Management.Models
{
    public class MaintanceRequest
    {
        public int idMaintanceRequest { get; set; }
        public int idItem { get; set; }
        public int? idPIC { get; set; }
        public int? idCheck { get; set; }
        public string status { get; set; }
        public string reason { get; set; }
        public decimal budgetEstimate { get; set; }
        public DateTime date { get; set; }
        public string type { get; set; }
        public string image { get; set; }
        public int extend { get; set; }
        public string reasonManager { get; set; }

        public MaintanceRequest() { }

        public MaintanceRequest(int idMaintanceRequest, int idItem, int idPIC, int idCheck, string status, string reason,
            decimal budgetEstimate, DateTime date, string type, string image, int extend, string reasonManager)
        {
            this.idMaintanceRequest = idMaintanceRequest;
            this.idItem = idItem;
            this.idPIC = idPIC;
            this.idCheck = idCheck;
            this.status = status;
            this.reason = reason;
            this.budgetEstimate = budgetEstimate;
            this.date = date;
            this.type = type;
            this.image = image;
            this.extend = extend;
            this.reasonManager = reasonManager;
        }
    }
}
