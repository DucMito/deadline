﻿namespace Factory_Equipment_Management.Models
{
    public class Token
    {
        public int id { get; set; }
        public string token { get; set; }

        public Token() { }

        public Token(int id, string token)
        {
            this.id = id;
            this.token = token;
        }
    }
}
