﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.Repository;
using Factory_Equipment_Management.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Factory_Equipment_Management.Controllers
{
    [Authorize]
    public class ManagerDeviceController : Controller
    {
        private readonly ItemDetailRepository _itemDetailRepository;
        private readonly ManagerDeviceRepository _repository;
        private readonly YourDbContext _context;

        public ManagerDeviceController(
            ManagerDeviceRepository repository,
            YourDbContext context,
            ItemDetailRepository itemDetailRepository
        )
        {
            _repository = repository;
            _context = context;
            _itemDetailRepository = itemDetailRepository;
        }

        [HttpGet]
        public async Task<IActionResult> GetItemImage(int id)
        {
            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == id);
            if (item == null || string.IsNullOrEmpty(item.image))
                return NotFound();

            try
            {
                string hex = item.image.Replace("-", "").Replace(" ", "");
                if (hex.Length % 2 != 0)
                    hex = "0" + hex;

                int numberChars = hex.Length;
                byte[] bytes = new byte[numberChars / 2];
                for (int i = 0; i < numberChars; i += 2)
                {
                    bytes[i / 2] = Convert.ToByte(hex.Substring(i, 2), 16);
                }

                return File(bytes, "image/jpeg");
            }
            catch
            {
                var defaultPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "no-image.jpg");
                var defaultBytes = System.IO.File.ReadAllBytes(defaultPath);
                return File(defaultBytes, "image/jpeg");
            }
        }

        [HttpGet]
        public async Task<IActionResult> Index(
            string status, int pageNumber = 1, int pageSize = 8,
            string filterDeviceName = null, string filterLocation = null,
            string filterModel = null,
            string filterSerialNumber = null,
            string filterSupplier = null,
            string filterContractor = null)
        {
            var userRole = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value ?? "";
            var (items, totalItems) = await _repository.GetDevicesAsync(
                pageNumber, pageSize, status,
                filterDeviceName, filterLocation,
                // filterActivedDate, filterMaintanceDate, filterRenewDate, // Không cần
                filterModel, filterSerialNumber, filterSupplier, filterContractor); ;

            // Truyền danh sách kho về ViewBag để render dropdown
            ViewBag.Warehouses = await _context.Warehouses.ToListAsync();
            ViewBag.Categories = await _context.Categories.ToListAsync();
            ViewBag.StatusList = await _context.Items
                .Where(i => i.status != null && i.status != "")
                .Select(i => i.status)
                .Distinct()
                .ToListAsync();

            var viewModel = new ManagerDeviceViewModel
            {
                UserRole = userRole,
                Items = items,
                PageNumber = pageNumber,
                PageSize = pageSize,
                TotalItems = totalItems,
                TotalPages = (int)Math.Ceiling((double)totalItems / pageSize),
                FilterDeviceName = filterDeviceName,
                FilterLocation = filterLocation,
                // FilterActivedDate = filterActivedDate,      // Không cần
                // FilterMaintanceDate = filterMaintanceDate,  // Không cần
                // FilterRenewDate = filterRenewDate,          // Không cần
                FilterModel = filterModel,
                FilterSerialNumber = filterSerialNumber,
                FilterSupplier = filterSupplier,
                FilterContractor = filterContractor
            };
            return View("ManagerDevice", viewModel);
        }


        [Authorize(Roles = "Admin,Manager,PIC")]
        [HttpPost]
        public async Task<IActionResult> ChangeStatus(int id)
        {
            var result = await _repository.ChangeStatusAsync(id, User);
            return Json(new { success = result });
        }

        [HttpGet("/ManagerDevice/Detail/{id}")]
        public async Task<IActionResult> Detail(int id)
        {
            var model = await _itemDetailRepository.GetItemDetailAsync(id);
            if (model == null) return NotFound();
            return View("~/Views/ItemDetails.cshtml", model);
        }



        [HttpPost]
        public async Task<IActionResult> ToggleStatus(int id)
        {
            var item = await _context.Items.FirstOrDefaultAsync(i => i.idItem == id);
            if (item == null) return NotFound();

            item.status = item.status == "Hoạt động" ? "Dự phòng" : "Hoạt động";
            await _context.SaveChangesAsync();
            return Json(new { status = item.status });
        }

        [HttpGet]
        public async Task<IActionResult> Filter(
     string status,
     int pageNumber = 1,
     int pageSize = 8,
     string filterDeviceName = null,
     string filterLocation = null,
     string filterModel = null,
     string filterSerialNumber = null,
     string filterSupplier = null,
     string filterContractor = null)
        {
            var userRole = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value ?? "";
            (List<DeviceDisplayModel> items, int totalItems) = await _repository.GetDevicesAsync(
                pageNumber, pageSize, status,
                filterDeviceName, filterLocation,
                filterModel, filterSerialNumber, filterSupplier, filterContractor);

            ViewBag.Warehouses = await _context.Warehouses.ToListAsync();
            ViewBag.Categories = await _context.Categories.ToListAsync();
            ViewBag.StatusList = await _context.Items
                .Where(i => i.status != null && i.status != "")
                .Select(i => i.status)
                .Distinct()
                .ToListAsync();

            var model = new ManagerDeviceViewModel
            {
                UserRole = userRole,
                Items = items,
                PageNumber = pageNumber,
                PageSize = pageSize,
                TotalItems = totalItems,
                TotalPages = (int)Math.Ceiling((double)totalItems / pageSize),
                FilterDeviceName = filterDeviceName,
                FilterLocation = filterLocation,
                // FilterActivedDate = filterActivedDate,      // Không cần
                // FilterMaintanceDate = filterMaintanceDate,  // Không cần
                // FilterRenewDate = filterRenewDate,          // Không cần
                FilterModel = filterModel,
                FilterSerialNumber = filterSerialNumber,
                FilterSupplier = filterSupplier,
                FilterContractor = filterContractor
            };
            return View("ManagerDevice", model);
        }

        public async Task<IActionResult> ManagerDevice(string status, int pageNumber = 1, int pageSize = 8)
        {
            var userRole = User.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value ?? "";
            var (items, totalItems) = await _repository.GetDevicesAsync(pageNumber, pageSize, status);
            ViewBag.Warehouses = await _context.Warehouses.ToListAsync();
            ViewBag.Categories = await _context.Categories.ToListAsync();
            ViewBag.StatusList = await _context.Items
                 .Where(i => i.status != null && i.status != "")
                 .Select(i => i.status)
                 .Distinct()
                 .ToListAsync();
            var model = new ManagerDeviceViewModel
            {
                UserRole = userRole,
                Items = items,
                PageNumber = pageNumber,
                PageSize = pageSize,
                TotalItems = totalItems,
                TotalPages = (int)Math.Ceiling((double)totalItems / pageSize)
            };
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> GetAreasByWarehouse(int idWarehouse)
        {
            var areas = await _context.Areas
                .Where(a => a.idWarehouse == idWarehouse)
                .Select(a => new { a.idArea, a.name })
                .ToListAsync();
            return Json(areas);
        }

        [HttpGet]
        public async Task<IActionResult> GetItemDetailJson(int id)
        {
            var item = await _repository.GetByIdAsync(id);
            if (item == null) return NotFound();

            // Lấy idWarehouse từ area (nếu có)
            int? idWarehouse = null;
            if (item.idArea != null)
            {
                var area = await _context.Areas.FirstOrDefaultAsync(a => a.idArea == item.idArea);
                idWarehouse = area?.idWarehouse;
            }

            return Json(new
            {
                idItem = item.idItem,
                itemName = item.po,
                status = item.status,
                activedDate = item.activedDate,
                maintanceDate = item.maintanceDate,
                renewDate = item.renewDate,
                idArea = item.idArea,
                idCategory = item.idCategory,
                idWarehouse = idWarehouse,
                comment = item.comment,                // BỔ SUNG
                serialNumber = item.serialNumber,  // BỔ SUNG
                supplier = item.supplier,          // BỔ SUNG
                contractor = item.contractor
            });
        }

        [Authorize(Roles = "Admin,Manager,PIC")]
        [HttpPost]
        public async Task<IActionResult> UpdateDevice([FromBody] DeviceDisplayModel model)
        {
            try
            {
                var result = await _repository.UpdateDeviceAsync(model);
                if (!result)
                {
                    return Json(new { success = false, message = "Cập nhật thiết bị không thành công. Vui lòng kiểm tra lại thông tin hoặc thử lại sau. Hãy nhập đầy đủ thông tin" });
                }
                return Json(new { success = true, message = "Cập nhật thiết bị thành công!" });
            }
            catch (Exception)
            {
                return Json(new { success = false, message = "Đã xảy ra lỗi trong quá trình cập nhật. Vui lòng thử lại hoặc liên hệ quản trị viên." });
            }
        }

        [Authorize(Roles = "Admin,Manager,PIC")]
        [HttpPost]
        public async Task<IActionResult> DeleteDevice(int id)
        {
            var result = await _repository.DeleteDeviceAsync(id);
            if (result)
                return Ok();
            return NotFound();
        }

       
    }
}