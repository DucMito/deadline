﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.Repository;
using Factory_Equipment_Management.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Factory_Equipment_Management.Controllers
{
    [Authorize(Roles = "Admin,Manager,PIC")]
    public class RegisterDeviceController : Controller
    {
        private readonly RegisterDeviceRepository _repository;
        private readonly YourDbContext _context;

        public RegisterDeviceController(RegisterDeviceRepository repository, YourDbContext context)
        {
            _repository = repository;
            _context = context;
        }

        public IActionResult Index(int page = 1, string status = null)
        {
            int pageSize = 8;
            int totalCount;
            var requests = _repository.GetPagedRequests(page, pageSize, out totalCount, status);

            var viewModel = new RegisterDeviceViewModel
            {
                Requests = requests,
                CurrentPage = page,
                TotalPages = (int)Math.Ceiling((double)totalCount / pageSize)
            };

            // Truyền categories cho view
            var categories = _context.Categories
                .Select(c => new { c.idCategory, c.name })
                .ToList();
            ViewBag.Categories = categories;

            // Truyền realCategories cho view
            var realCategories = _context.RealCategories
                .Select(rc => new { rc.idRealCategory, rc.name })
                .ToList();
            ViewBag.RealCategories = realCategories;

            return View("RegisterDevice", viewModel);
        }

        [HttpGet]
        public IActionResult GetDeviceDetail(int id)
        {
            var detail = _repository.GetDeviceDetail(id);
            if (detail == null)
                return NotFound();
            return Json(detail);
        }

        // Nhận form, lưu vào DB, không kiểm tra gì thêm
        [HttpPost]
        public async Task<IActionResult> Create(RegisterDeviceCreateViewModel model)
        {
            var result = await _repository.AddRegisterDeviceAsync(model);
            if (result)
                return Ok(new { success = true });
            else
                return StatusCode(500, new { success = false, message = "Không lưu được dữ liệu." });
        }
    }
}