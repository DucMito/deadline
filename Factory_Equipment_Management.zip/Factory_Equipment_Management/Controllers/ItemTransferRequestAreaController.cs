﻿using Factory_Equipment_Management.Models;
using Factory_Equipment_Management.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;


[Authorize(Roles = "Admin,Manager,PIC")]
public class ItemTransferRequestAreaController : Controller
{
    
    private readonly ItemTransferRequestAreaRepository _itemTransferRequestAreaRepositoryrepository;

    public ItemTransferRequestAreaController(ItemTransferRequestAreaRepository itemTransferRequestAreaRepositoryrepository)
    {
        _itemTransferRequestAreaRepositoryrepository = itemTransferRequestAreaRepositoryrepository;
    }

    public async Task<IActionResult> Index()
    {
        var model = await _itemTransferRequestAreaRepositoryrepository.GetViewModelAsync();
        // Lấy từ cookie
        ViewBag.UserId = Request.Cookies["UserId"] ?? "0";
        ViewBag.UserRole = Request.Cookies["Role"] ?? "";
        return View("~/Views/ItemTransferRequestArea.cshtml", model);
    }

    [HttpGet]
    public async Task<IActionResult> GetDevices(string warehouse, string area, int page = 1, int pageSize = 10)
    {
        var (items, totalCount) = await _itemTransferRequestAreaRepositoryrepository.GetDevicesByWarehouseAndAreaPagedAsync(warehouse, area, page, pageSize);
        return Json(new { items, totalCount });
    }

    [HttpGet]
    public async Task<IActionResult> GetNewProducts(int page = 1, int pageSize = 10)
    {
        var (items, totalCount) = await _itemTransferRequestAreaRepositoryrepository.GetNewProductsPagedAsync(page, pageSize);
        return Json(new { items, totalCount });
    }
    [HttpPost]
    public async Task<IActionResult> CreateTransferRequest([FromBody] TransferRequestInputModel model)
    {
        if (model == null || model.ItemIds == null || !model.ItemIds.Any())
            return BadRequest("Chưa chọn sản phẩm.");

        try
        {
            var result = await _itemTransferRequestAreaRepositoryrepository.CreateTransferRequestAsync(model);
            return Json(new { success = result });
        }
        catch (Exception ex)
        {
            // Trả về lỗi chi tiết nhất có thể
            return BadRequest(ex.InnerException?.Message ?? ex.Message);
        }
    }


}