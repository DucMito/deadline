﻿namespace Factory_Equipment_Management.Models
{
    public class Manager
    {
        public int idManager { get; set; }
        public string name { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public bool active { get; set; }
        public bool admin { get; set; }

        // Constructor có tham số
        public Manager(int idManager, string name, string username, string password, string email, bool active, bool admin)
        {
            this.idManager = idManager;
            this.name = name;
            this.username = username;
            this.password = password;
            this.email = email;
            this.active = active;
            this.admin = admin;
        }


        public Manager() { }
    }

}
