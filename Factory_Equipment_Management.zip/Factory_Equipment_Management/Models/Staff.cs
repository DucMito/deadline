﻿namespace Factory_Equipment_Management.Models
{
    public class Staff
    {
        public int idStaff { get; set; }
        public string? name { get; set; }
        public string? username { get; set; }
        public string? password { get; set; }
        public string? email { get; set; }

        public Staff() { }

        public Staff(int idStaff, string name, string username, string password, string email)
        {
            this.idStaff = idStaff;
            this.name = name;
            this.username = username;
            this.password = password;
            this.email = email;
        }
    }
}
