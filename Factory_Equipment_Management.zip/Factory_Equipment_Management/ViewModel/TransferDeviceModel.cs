﻿namespace Factory_Equipment_Management.ViewModel
{
    public class TransferDeviceModel
    {
        public int Id { get; set; }
        public string DeviceType { get; set; }
        public string ImageUrl { get; set; }
        public string Status { get; set; }
        public string ActivedDate { get; set; }
        public int Quantity { get; set; }
        public int TransferQuantity { get; set; }
        public bool IsSelected { get; set; }

        public DateTime? TransferDate { get; set; }
        public string OldLocation { get; set; }
        public string NewLocation { get; set; }
        public List<MaintenanceHistoryModel> MaintenanceHistory { get; set; }
        public List<TransferDeviceModel> TransferHistory { get; set; }
    }
}