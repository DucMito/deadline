﻿using Factory_Equipment_Management.Models;

namespace Factory_Equipment_Management.ViewModel
{
    public class ItemWithCategoryViewModel
    {
        public string Name { get; set; }
        public int? IdCategory { get; set; }
        public int? MaintanceCycle { get; set; }
        public int? Duration { get; set; }
        public int? AlertMaintance { get; set; }
        public int? AlertRenew { get; set; }
    }

}