﻿namespace Factory_Equipment_Management.ViewModel
{
    public class InforItemViewModel
    {
        public int? IdCategory { get; set; }
        public string Name { get; set; }
        public string ImageBase64 { get; set; }
        public float? MaintanceCycle { get; set; }
        public float? Duration { get; set; }         
        public double? AlertMaintance { get; set; }
        public double? AlertRenew { get; set; }

        // Thêm 2 trường của realCategory

        public int idRealCategory { get; set; }
        public string nameRealCategory { get; set; }

        public string NewRealCategory { get; set; } // dùng cho trường hợp chọn Other


    }
}