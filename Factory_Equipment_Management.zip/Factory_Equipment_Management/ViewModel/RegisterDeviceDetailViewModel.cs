﻿namespace Factory_Equipment_Management.ViewModel
{
    public class RegisterDeviceDetailViewModel
    {
        public string Name { get; set; }
        public string ImageBase64 { get; set; } // Đổi tên cho rõ ràng
        public int Num { get; set; }
        public string PO { get; set; }
        public float MaintainceCycle { get; set; }
        public float RenewCycle { get; set; }
    }
}
