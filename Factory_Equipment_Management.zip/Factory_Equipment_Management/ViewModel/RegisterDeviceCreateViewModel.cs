﻿using System.ComponentModel.DataAnnotations;

public class RegisterDeviceCreateViewModel
{
    [Required(ErrorMessage = "Vui lòng chọn loại thiết bị")]
    public int CategoryId { get; set; }

    [Required(ErrorMessage = "Vui lòng nhập tên thiết bị")]
    public string Name { get; set; }

    [Required(ErrorMessage = "Vui lòng chọn loại tài sản")]
    public int Type { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Số lượng phải lớn hơn 0")]
    public int Num { get; set; }

    public string PO { get; set; }
    public IFormFile Image { get; set; }
    public float? MaintainceCycle { get; set; }
    public float? RenewCycle { get; set; }
    public float? AlertMaintaince { get; set; }
    public float? AlertRenew { get; set; }
    public DateTime? DangKiemDate { get; set; }

    [Required(ErrorMessage = "Vui lòng chọn loại thực tế")]
    public int? IdRealCategory { get; set; }
}